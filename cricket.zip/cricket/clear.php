<?php
$key1=$_POST['key1'];
if($key1=="admin123"){
$cc=fopen("cricket.php","w");
fwrite($cc,"");
fclose($cc);

$ca=fopen("needrun.php","w");
fwrite($ca,"");
fclose($ca);

$runc=fopen("cricketrun.php","w");
fwrite($runc,"");
fclose($runc);

$nbc=fopen("cricketnb.php","w");
fwrite($nbc,"");
fclose($nbc);


$wkc=fopen("cricketwk.php","w");
fwrite($wkc,"");
fclose($wkc);

$ballc=fopen("cricketball.php","w");
fwrite($ballc,"");
fclose($ballc);

$overc=fopen("cricketover.php","w");
fwrite($overc,"");
fclose($overc);

$wtc=fopen("cricketwt.php","w");
fwrite($wtc,"");
fclose($wtc);

$trunc=fopen("totalrun.php","w");
fwrite($trunc,"");
fclose($trunc);

$tnbc=fopen("totalnb.php","w");
fwrite($tnbc,"");
fclose($tnbc);


$twkc=fopen("totalwk.php","w");
fwrite($twkc,"");
fclose($twkc);

$tballc=fopen("totalball.php","w");
fwrite($tballc,"");
fclose($tballc);

$toverc=fopen("totalover.php","w");
fwrite($toverc,"");
fclose($toverc);

$twtc=fopen("totalwt.php","w");
fwrite($twtc,"");
fclose($twtc);

header("location:home.php");
}else{
header("location:clear_verify.php");
}
?>