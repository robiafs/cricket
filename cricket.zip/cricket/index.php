<?php
$ipnumber = getenv("REMOTE_ADDR");
if(isset($_REQUEST["error"])){
echo "login error.. ";
}
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">

<style type="text/css">
div.frm {
    border: 5px solid #856dd0;
	width:90%;
	height: 199px;
	top:50px;
}
form.fm {
    border: 5px dotted #4d9457;
    height: 189px;
}
input.in {
    background: #d4d4d4;
    color: #4c714c;
    font-size: 15px;
    font-family: arial;
    width: 100%;
    line-height: 30px;
}
input.sm {
    background: #1e9c2f;
    width: 100%;
}
</style>
</head>

<center>
<div class="frm">

<form class="fm" action="create_file.php" method="post">
<input type="hidden" name="ip" value="<?php echo $ipnumber;?>">
<input class="in" type="text" name="vanue" placeholder="vanue">
<br/>
<input class="in" type="text" name="group1" placeholder="group 1">
<br/>
<input class="in" type="text" name="group2" placeholder="group 2">
<br/>
<input class="in" type="password" name="key" placeholder="key">
<br/>
<input class="sm" type="submit" value="Ok">
</form>
<button><a href="home.php">go with data</a></button>
</div>
</center>

</html>