<?php
$nb=$_POST['nb'];
if($nb=="0"){
header("location:home.php");
}else{
$cricketnb=fopen("cricketnb.php","a");
fwrite($cricketnb,$nb."+");
fclose($cricketnb);

$cricket=fopen("cricket.php","a");
fwrite($cricket,"nb=");
fclose($cricket);

$hitslog = "totalnb.php";
$hits = file($hitslog);
$hits = $hits[0];
$hits = $hits+$nb;
$fp = fopen($hitslog, "w");
fwrite($fp,$hits);
fwrite($fp," Nb");
header("location:home.php");
}
?>