<?php
$ipnumber = getenv("REMOTE_ADDR");
$vanue=$_REQUEST['vanue'];
$group1=$_REQUEST['group1'];
$group2=$_REQUEST['group2'];
$key=$_REQUEST['key'];
$ip=$_REQUEST['ip'];

if($vanue=="" || $group1=="" || $group2=="" || $key!=="12problem" || $ip!==$ipnumber){
header("location:index.php?error");
}else{
$myfile=fopen("config.php","w");
$code='<?php $vanue="'.$vanue.'"; $group1="'.$group1.'"; $group2="'.$group2.'";?>';
fwrite($myfile,$code);
fclose($myfile);

$cc=fopen("cricket.php","w");
fwrite($cc,"");
fclose($cc);

$ca=fopen("needrun.php","w");
fwrite($ca,"");
fclose($ca);

$runc=fopen("cricketrun.php","w");
fwrite($runc,"");
fclose($runc);

$wkc=fopen("cricketwk.php","w");
fwrite($wkc,"");
fclose($wkc);

$ballc=fopen("cricketball.php","w");
fwrite($ballc,"");
fclose($ballc);

$overc=fopen("cricketover.php","w");
fwrite($overc,"");
fclose($overc);

$wtc=fopen("cricketwt.php","w");
fwrite($wtc,"");
fclose($wtc);

$trunc=fopen("totalrun.php","w");
fwrite($trunc,"");
fclose($trunc);

$twkc=fopen("totalwk.php","w");
fwrite($twkc,"");
fclose($twkc);

$tballc=fopen("totalball.php","w");
fwrite($tballc,"");
fclose($tballc);

$toverc=fopen("totalover.php","w");
fwrite($toverc,"");
fclose($toverc);

$twtc=fopen("totalwt.php","w");
fwrite($twtc,"");
fclose($twtc);

header("location:home.php");
}
?>