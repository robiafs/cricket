<?php
$ball=$_POST['ball'];
if($ball=="0"){
header("location:home.php");
}else{
$cricketball=fopen("cricketball.php","a");
fwrite($cricketball,$ball."+");
fclose($cricketball);

$cricket=fopen("cricket.php","a");
fwrite($cricket,"ball=");
fclose($cricket);

$hitslog = "totalball.php";
$hits = file($hitslog);
$hits = $hits[0];
$hits = $hits+$ball;
$fp = fopen($hitslog, "w");
fwrite($fp,$hits);
fwrite($fp," Ball");

$cball = $hits+$ball-1;
if($cball=="6" || $cball=="12" || $cball=="18" || $cball=="24" || $cball=="30" || $cball=="36" || $cball=="42" || $cball=="48" || $cball=="54" || $cball=="60" || $cball=="66" || $cball=="72" || $cball=="78" || $cball=="84" || $cball=="90" || $cball=="96" || $cball=="102" || $cball=="108" || $cball=="114" || $cball=="120" || $cball=="126" || $cball=="132" || $cball=="138" || $cball=="144" || $cball=="150" || $cball=="156" || $cball=="162" || $cball=="168" || $cball=="174" || $cball=="180" || $cball=="186" || $cball=="192" || $cball=="198" || $cball=="204" || $cball=="210" || $cball=="216" || $cball=="222" || $cball=="228" || $cball=="234" || $cball=="240" || $cball=="246" || $cball=="252" || $cball=="258" || $cball=="264" || $cball=="270" || $cball=="276" || $cball=="282" || $cball=="288" || $cball=="294" || $cball=="300"){
$cricketballc=fopen("cricketball.php","w");
fwrite($cricketballc,"");
fclose($cricketballc);

$cricketover=fopen("cricketover.php","a");
fwrite($cricketover,"1+");
fclose($cricketover);

$cricket=fopen("cricket.php","a");
fwrite($cricket,"over, ");
fclose($cricket);

$hitslog = "totalover.php";
$hits = file($hitslog);
$hits = $hits[0];
$hits = $hits+1;
$fp = fopen($hitslog, "w");
fwrite($fp,$hits);
fwrite($fp," Over");
}
header("location:home.php");
}
?>