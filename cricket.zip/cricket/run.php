<?php
$run=$_POST['run'];
if($run=="0"){
$cricket=fopen("cricket.php","a");
fwrite($cricket,"0, ");
fclose($cricket);
header("location:home.php");
}else{
$cricketrun=fopen("cricketrun.php","a");
fwrite($cricketrun,$run."+");
fclose($cricketrun);

$cricket=fopen("cricket.php","a");
fwrite($cricket,$run.", ");
fclose($cricket);

$hitslog = "totalrun.php";
$hits = file($hitslog);
$hits = $hits[0];
$hits = $hits+$run;
$ah = $hits+1;
$fp = fopen($hitslog, "w");
fwrite($fp,$hits);
fwrite($fp," Run");

$fg = fopen("needrun.php", "w");
fwrite($fg,$ah);
fwrite($fg," Ran Need");
header("location:home.php");
}
?>