<?php
$wt=$_POST['wt'];
if($wt=="0"){
header("location:home.php");
}else{
$cricketwt=fopen("cricketwt.php","a");
fwrite($cricketwt,$wt."+");
fclose($cricketwt);

$cricket=fopen("cricket.php","a");
fwrite($cricket,"wd, ");
fclose($cricket);

$hitslog = "totalwt.php";
$hits = file($hitslog);
$hits = $hits[0];
$hits = $hits+$wt;
$fp = fopen($hitslog, "w");
fwrite($fp,$hits);
fwrite($fp," Wd");
header("location:home.php");
}
?>