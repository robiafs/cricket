<?php
require_once("config.php");
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">

<style type="text/css">
div.tbl {
    border: 5px solid #856dd0;
}
input.cricketi {
    background: #f1ecf7;
    width: 100%;
    height: 40px;
    border: none;
}
center.cn{
	width: 100%;
	height: 40px;
    font-size: 18px;
    border: none;
    background: #746982;
    color: white;
}
td.cricket {
    width: 100%;
    height: 40px;
    border: none;
    background: #746982;
    color: white;
}
input.submit {
    background-color: #4CAF50; /* Green */
    border: none;
    width:100%;
    height:40px;
    padding-top:05px;
    color: white;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 12px;
    cursor: pointer;
    float: center;
}
input.submit1 {
    background-color: #4CAF50;
    border: none;
    width: 100%;
    height: 18px;
    color: white;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 12px;
    cursor: pointer;
}
.submit:hover, .submit1:hover{
    background-color: #ff9933;
}
#tf form {
    height: 0.5px;
}
td{
	width:33.33%;
}
form {
    height: 23px;
}
</style>

</head>
<body>

<div class="tbl">
<center><?php echo $vanue;?></center>
<table width="100%" border="1">
<tr>
<td width="100%" colspan="3">
<center class="cn"><?php echo $group1;?></center>
</td>
</tr>

<tr>
<td>
<table id="tf" border="0" width="100%">
<tr>
<td>
<form action="run.php" method="post">
<input name="run" type="hidden" value="1">
<input class="submit1" type="submit" value="1">
</form>
</td>
<td>
<form action="run.php" method="post">
<input name="run" type="hidden" value="2">
<input class="submit1" type="submit" value="2">
</form>
</td>
<td>
<form action="run.php" method="post">
<input name="run" type="hidden" value="3">
<input class="submit1" type="submit" value="3">
</form>
</td>
</tr>
<tr>
<td>
<form action="run.php" method="post">
<input name="run" type="hidden" value="4">
<input class="submit1" type="submit" value="4">
</form>
</td>
<td>
<form action="run.php" method="post">
<input name="run" type="hidden" value="6">
<input class="submit1" type="submit" value="6">
</form>
</td>
<td>
<form action="run.php" method="post">
<input name="run" type="hidden" value="0">
<input class="submit1" type="submit" value="0">
</form>
</td>
</tr>
</table>
</td>
<td>
<input class="cricketi" width="100%" value="<?php include 'cricketrun.php';?>"/>
</td>
<td>
<?php include 'totalrun.php';?>
</td>
</tr>

<tr>
<td>
<form action="wk.php" method="post">
<input name="wk" type="hidden" value="1">
<input class="submit" type="submit" value="Add Wk">
</form>
</td>
<td>
<input class="cricketi" width="100%" value="<?php include 'cricketwk.php';?>"/>
</td>
<td>
<?php include 'totalwk.php';?>
</td>
</tr>

<tr>
<td>
<form action="ball.php" method="post">
<input name="ball" type="hidden" value="1">
<input class="submit" type="submit" value="Add Ball">
</form>
</td>
<td>
<input class="cricketi" width="100%" value="<?php include 'cricketball.php';?>"/>
</td>
<td>
<?php include 'totalball.php';?>
</td>
</tr>

<tr>
<td>
<form action="wt.php" method="post">
<input name="wt" type="hidden" value="1">
<input class="submit" type="submit" value="Add Wd">
</form>
</td>
<td>
<input class="cricketi" width="100%" value="<?php include 'cricketwt.php';?>"/>
</td>
<td>
<?php include 'totalwt.php';?>
</td>
</tr>

<tr>
<td>
<form action="nb.php" method="post">
<input name="nb" type="hidden" value="1">
<input class="submit" type="submit" value="Add Nb">
</form>
</td>
<td>
<input class="cricketi" width="100%" value="<?php include 'cricketnb.php';?>"/>
</td>
<td>
<?php include 'totalnb.php';?>
</td>
</tr>

<tr>
<td>
<center>
<a href="clear_verify.php">
<img src="ball.png" height="41px" alt="clear">
</a>
</center>
</td>
<td>
<input class="cricketi" width="100%" value="<?php include 'cricketover.php';?>"/>
</td>
<td>
<?php include 'totalover.php';?>
</td>
</tr>

<tr>
<td class="cricket" width="100%" colspan="3">
<marquee direction="right">
<?php include 'cricket.php';?>
</marquee>
</td>
</tr>
</table>
</div>

<br/>
<div class="tbl" style="text-align:justify;padding:05px;font-size:15px;">
<?php include 'cricket.php';?>
</div>
<br/>
<button><a href="part2/clear_verify.php">reset and go <?php echo $group2;?></a></button>&nbsp;<button><a href="home2.php">go with data <?php echo $group2;?></a></button>
</body>
</html>