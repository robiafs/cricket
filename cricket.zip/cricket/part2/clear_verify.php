<html>
<head>
<meta name="viewport" content="width=device-width">

<style type="text/css">

div#tbl {
    border: 5px solid #856dd0;
}
input {
    background: #f1ecf7;
    width: 100%;
    height: 41px;
}
</style>

</head>
<body>
<div id="tbl">
<center>
<form method="post" action="clear.php">
<input type="password" name="key1">
<input type="submit" value="Cleared">
</form>
</center>
</div>
</body>
</html>