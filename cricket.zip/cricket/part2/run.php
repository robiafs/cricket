<?php
$run=$_POST['run'];
if($run=="0"){
$cricket=fopen("cricket.php","a");
fwrite($cricket,"0, ");
fclose($cricket);
header("location:../home2.php");
}else{
$cricketrun=fopen("cricketrun.php","a");
fwrite($cricketrun,$run."+");
fclose($cricketrun);

$cricket=fopen("cricket.php","a");
fwrite($cricket,$run.", ");
fclose($cricket);

$hitslog = "totalrun.php";
$hits = file($hitslog);
$hits = $hits[0];
$hits = $hits+$run;
$fp = fopen($hitslog, "w");
fwrite($fp,$hits);
fwrite($fp," Run");

$hitslogm = "../needrun.php";
$hitsm = file($hitslogm);
$hitsm = $hitsm[0];
$hitsm = $hitsm-$run;
$fpm = fopen($hitslogm,"w");
fwrite($fpm,$hitsm);
fwrite($fpm," Run Need");

header("location:../home2.php");
}
?>