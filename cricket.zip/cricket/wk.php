<?php
$wk=$_POST['wk'];
if($wk=="0"){
header("location:home.php");
}else{
$cricketwk=fopen("cricketwk.php","a");
fwrite($cricketwk,$wk."+");
fclose($cricketwk);

$cricket=fopen("cricket.php","a");
fwrite($cricket,"wk, ");
fclose($cricket);

$hitslog = "totalwk.php";
$hits = file($hitslog);
$hits = $hits[0];
$hits = $hits+$wk;
$fp = fopen($hitslog, "w");
fwrite($fp,$hits);
fwrite($fp," Wk");
header("location:home.php");
}
?>